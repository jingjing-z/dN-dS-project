#' Title
#'
#' @param input_parameter 
#'
#' @return
#' @export
#'
#' @examples
plot_codons <- function(input_parameter){
  df <- data.frame(
    codon_position = c(1:ncol(input_parameter)),
    parameter = input_parameter[1,],
    lb = input_parameter[2,],
    ub = input_parameter[3,]
  )
  
  p <- ggplot(df, aes(x=codon_position)) +
    geom_linerange(mapping=aes(ymin=lb, ymax=ub), size=0.8, color="grey") +
    geom_point(aes(y=parameter), size=1.2) +
    geom_hline(yintercept=0.5, linetype='dashed', size=0.9, col="red") +
    
    labs(x="codon position") +
    scale_y_continuous(
      limits = range(input_parameter),
      name = substitute(input_parameter),
      trans = log10_trans(),
      breaks = c(0.001, 0.01, 0.1, 0.5, 1, 10),
      labels = c(0.001, 0.01, 0.1, 0.5, 1, 10)) + 
    
    ggtitle(expression(italic(''))) +
    
    theme_bw() +
    theme(
      axis.title.x = element_text(size=15, hjust=.5, vjust=-1),
      axis.title.y = element_text(size=15, hjust=.5, vjust=2),
      axis.text.x = element_text(size=12),
      axis.text.y = element_text(size=12),
      # plot.title = element_text(size=25, hjust=.5),
      plot.margin = margin(1, 1, 1, 1, "cm")
    ) 
  
  return(p)
}


