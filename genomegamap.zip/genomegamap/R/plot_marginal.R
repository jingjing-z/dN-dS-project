#' Title
#'
#' @param parameter1
#' @param parameter2
#'
#' @return
#' @export
#'
#' @examples
plot_marginal <- function(parameter1, parameter2){
  # save the quoted parameters
  name_parameter1 <- paste(substitute(parameter1), collapse='')
  name_parameter2 <- paste(substitute(parameter2), collapse='')
  # create dataframe of these two parameters
  df_pars <- as.data.frame(matrix(c(parameter1[1,], parameter2[1,]), ncol=2))
  colnames(df_pars) <- c(name_parameter1, name_parameter2)

  # plot
  p <- ggplot(df_pars, aes(x=df_pars[,1], y=df_pars[,2])) +
    geom_point(color="dimgrey") +
    labs(x=name_parameter1, y=name_parameter2) +
    theme_bw(16)
  p_marginal <- ggMarginal(p, type="densigram",
                           xparams=list(fill="orange"),
                           yparams=list(fill="green"))
  return(p_marginal)
}


