#' @title Preprocess the data
#' @description This function is used to preprocess the FASTA data for the STAN model.
#' @param data_path FASTA file path
#'
#' @return the processed data
#' @export
#'
#' @examples
preprocess_raw_data <- function(data_path){
  raw_data <- read_fasta(data_path)
  seqs <- transcribe(raw_data)
  tripletNames_noSTO <- tripletNames()[-c(11, 12, 15)]
  l <- ncol(seqs) #length of the gene
  X <- matrix(NA, nrow=l, ncol=61)
  n <- rep(NA, l)
  pi <- rep(0.0163934426229508, 61) # can apply other options later (e.g. emperical)
  for (pos in 1:l){
    count <- as.data.frame(table(seqs[,pos]))
    order <- match(tripletNames_noSTO, count$Var1)
    x <- count$Freq[order]
    x[is.na(x)] <- 0
    X[pos,] <- x
    n[pos] <- sum(x)
  }
  data <- list(X=X, n=n, pi=pi, l=l)
  return(data)
}
