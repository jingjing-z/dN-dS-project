#' @title transcribe
#'
#' @param x
#'
#' @return
#' @export
#'
#' @examples
transcribe = function(x) {
  y = t(sapply(1:nrow(x),function(i) totriplet(x[i,])))
  rownames(y) = rownames(x)
  return(y)
}
