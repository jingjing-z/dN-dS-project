#' @title Compiling model
#' @description This function is used to compile the STAN model by cmdstanr.
#' @param model_file STAN model file (path)
#' @param seed set seed for MCMC
#' @param chains No. of chains of MCMC
#' @param par_chains No. of parallel chains of MCMC
#' @param warmup warmup iterations
#' @param sampling samping iterations
#'
#' @return results of the model: fit$summary()
#' @export
#'
#' @examples
compile_model <- function(model_file, seed, chains, par_chains, warmup, sampling){
  library(cmdstanr)
  # import and compile the model
  file <- file.path('./model/indep_model.stan')
  mod <- cmdstan_model(file)

  # fit the model
  fit <- mod$sample(
    data = data,
    seed = seed,
    chains = chains,
    parallel_chains = par_chains,
    iter_warmup = warmup,
    iter_sampling = sampling,
    # refresh = 500 # print update every 500 iters
  )
  return(fit)
}

