#' @title To triplet
#' @description
#' @param x
#'
#' @return
#' @export
#'
#' @examples
totriplet = function(x) {
  L = floor(length(x)/3)*3
  paste(x[seq(1,L,by=3)],x[seq(2,L,by=3)],x[seq(3,L,by=3)],sep="")
}
