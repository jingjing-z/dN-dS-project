#' @title Extracting results
#' @description This function is used to extract the STAN results of the compiled model.
#' @param parameter select which parameter you'd like to extract and navigate
#' @param fit name of summary results of the compiled model
#'
#' @return
#' @export
#'
#' @examples
extract_results <- function(fit, parameter){
  df <- as.data.frame(fit$draws(paste(substitute(parameter), collapse='')))
  results <- apply(df, 2, quantile, c(0.5,0.025,0.975))
  return(results)
}
